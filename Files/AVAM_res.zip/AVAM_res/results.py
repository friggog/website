#!/usr/bin/env python
import csv
import numpy as np
from scipy.stats import friedmanchisquare, wilcoxon  # , kstest


def CronbachAlpha(itemscores):
    itemscores = np.asarray(itemscores)
    itemvars = itemscores.var(axis=0, ddof=1)
    tscores = itemscores.sum(axis=1)
    nitems = itemscores.shape[1]
    calpha = nitems / float(nitems - 1) * (1 - itemvars.sum() / float(tscores.var(ddof=1)))
    return calpha


base = 26
n_per_page = 29
data = []
ages = []

with open('AVAM.csv', 'r',) as csvfile:
    spamreader = csv.reader(csvfile, delimiter=',', quotechar='"')
    for i, row in enumerate(spamreader):
        if i <= 1:
            continue
        ages.append(int(row[9]))
        data.append(row[base:-1])
data = np.array(data).astype(float)
print('Mean age:', np.mean(ages))
print('Std age: ', np.std(ages))
print('Ages between', np.min(ages), 'and', np.max(ages))

# index as [participant, page, question]
data = data.reshape((-1, 7, n_per_page))
data[:, :, 26] = 6 - data[:, :, 26]  # flip danger/safety question

# INDICES
# INCLUDED UTAUT ASPECTS
PERF_EXP = ('PERFORMANCE EXPECTANCY', slice(3, 6))
EFF_EXP = ('EFFORT EXPECTANCY', slice(6, 9))  # PEU IN RODEL
ATT = ('ATTITUDE', slice(9, 12))
SOC_INF = ('SOCIAL INFLUENCE', slice(12, 15))
FAC_CON = ('FACILITATING CONDITIONS', slice(15, 18))
SEL_EFF = ('SELF-EFFICACY', slice(18, 21))
ANX = ('ANXIETY', slice(21, 24))
BEH_INT = ('BEHAVIOURAL INTENTION', slice(24, 26))  # BI IN RODEL
PER_SAF = ('PERCEIVED SAFETY', slice(26, 29))
# DIRECT TO RODEL
PEU = ('PEU', EFF_EXP[1])
PBC = ('BEHAVIOURAL CONTROL', slice(15, 17))
FUN = ('FUN', 11)
TRUST = ('TRUST', 28)

###################################################################################################
# CHANGE THESE VARIABLE TO ALTER OUTPUTS
SIG_DIFF = 0      # display which differences between levels are significant (wilcoxon)
SIG_CORR = 0      # display which elements are significantly correlated to level (friedman chi squared)
PLOTS = 1         # output PGFplots data
CONSISTENCY = 0   # output Cronbach's alpha
BODY_PARTS = 1    # whether to evaluate AVAM or body part importance question RQ4

# WHICH 'PAGES' I.E. SCENARIOS TO INLUDE IN THE RESULTS
# PAGES = {'0': 0, '1': 1, '2': 2, '3': 3, '4A': 4, '4B': 5, '5': 6}  # all scenarios
PAGES = {'0': 0, '1': 1, '2': 2, '3': 3, '4': 4, '5': 6}  # all but exluding 4B (i.e. that used for results to RQ1)
# PAGES = {'0': 0, '1': 1, '2': 2, '4': 4, '5': 6}  # all excluding level 3 (i.e. that used for results to RQ2)
# PAGES = {'A': 4, 'B': 5}  # 4A and 4B (i.e. that used for results to RQ3)

# WHICH ELEMENTS OF THE AVAM TO INCLUDE IN THE RESULTS
FACTORS = [PERF_EXP, EFF_EXP, SOC_INF, FAC_CON, ATT, SEL_EFF, ANX, BEH_INT, PER_SAF]  # all for RQ1/RQ3
# FACTORS = [PBC, PEU, BEH_INT, ATT]  # , TRUST, FUN]  # rodel elements for RQ2
# FACTORS = [('Q' + str(i - 2), i) for i in range(3, n_per_page)] # each question individually (excluding body parts questions)
###################################################################################################

if not BODY_PARTS:
    for fname, ind in FACTORS:
        print(fname)
        if CONSISTENCY:
            print('Cronbach\'s Alpha:', round(CronbachAlpha(data[:, :, ind].reshape((-1, data[:, :, ind].shape[2]))), 3))
            print()
        for pind, (name, page) in enumerate(PAGES.items()):
            this_data = data[:, page, ind]
            # mean is straightforward
            m = np.mean(this_data)
            # for quartiles take the average of quartiles across all included questions
            uq = []
            lq = []
            if len(this_data.shape) == 1:
                uq.append(np.percentile(this_data, 75))
                lq.append(np.percentile(this_data, 25))
            else:
                for x in range(this_data.shape[1]):
                    uq.append(np.percentile(this_data[:, x], 75))
                    lq.append(np.percentile(this_data[:, x], 25))
            uq = np.mean(uq)
            lq = np.mean(lq)
            # output for pgfplots
            if PLOTS:
                print('(' + name + ', ' + str(round(m, 3)) + ') += (0, ' + str(round(uq - m, 3)) + ') -= (0, ' + str(round(m - lq, 3)) + ')')
            # sig diff tests
            if SIG_DIFF and pind < len(PAGES) - 1:
                # for name2, page2 in PAGES.items():
                    # if page < page2:
                name2, page2 = list(PAGES.items())[pind + 1]
                w = wilcoxon(data[:, page, ind].ravel(),
                             data[:, page2, ind].ravel(),
                             correction=True)
                p = w.pvalue
                # print(kstest(data[:, page, ind].ravel(), 'norm'))
                inc = np.mean(data[:, page, ind].ravel()) - np.mean(data[:, page2, ind].ravel()) < 0
                if p < 0.01:
                    print('-> Significant ' + ('increase' if inc else 'decrease') + ' from level', name, 'to', name2, ', p = %f' % p)
                else:
                    print(' Insignificant ' + ('increase' if inc else 'decrease') + ' from level', name, 'to', name2, ', p = %f' % p)
        # correlation to level sig test
        if len(PAGES) > 3:
            f = friedmanchisquare(*[data[:, i, ind].ravel() for i in PAGES.values()])
            if SIG_CORR and f.pvalue < 0.001:
                print('=> Significantly correlated with level by', round(f.statistic, 3), 'p = %f' % f.pvalue)
        print()

if BODY_PARTS:
    for bname, ind in [('HANDS', 0), ('FEET', 1), ('EYES', 2)]:
        print(bname)
        # correlation to level sig test
        if len(PAGES) > 3:
            f = friedmanchisquare(*[data[:, i, ind].ravel() for i in PAGES.values()])
            if SIG_CORR and f.pvalue < 0.001:
                print('=> Significantly correlated with level by', round(f.statistic, 3), 'p = %f' % f.pvalue)
        for pind, (name, page) in enumerate(PAGES.items()):
            if SIG_DIFF and pind < len(PAGES) - 1:
                # for name2, page2 in PAGES.items():
                    # if page < page2:
                name2, page2 = list(PAGES.items())[pind + 1]
                w = wilcoxon(data[:, page, ind].ravel(),
                             data[:, page2, ind].ravel(),
                             correction=True)
                p = w.pvalue
                inc = np.mean(data[:, page, ind].ravel()) - np.mean(data[:, page2, ind].ravel()) < 0
                if p < 0.01:
                    print('-> Significant ' + ('increase' if inc else 'decrease') + ' from level', name, 'to', name2, ', p = %f' % p)
                else:
                    print(' Insignificant ' + ('increase' if inc else 'decrease') + ' from level', name, 'to', name2, ', p = %f' % p)
            if PLOTS:
                this_data = data[:, page, ind]
                m = np.mean(this_data)
                uq = np.percentile(this_data, 75)
                lq = np.percentile(this_data, 25)
                print('(' + str(name) + ', ' + str(round(m, 3)) + ') += (0, ' + str(round(uq - m, 3)) + ') -= (0, ' + str(round(m - lq, 3)) + ')')
        print()
